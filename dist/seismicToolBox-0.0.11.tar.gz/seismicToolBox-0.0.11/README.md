# seismicToolBox
Some Python functions for sorting, plotting, semblance analysis, stacking, and migrating seismic data